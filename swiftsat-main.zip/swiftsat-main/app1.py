from flask import Flask, render_template, request
from PIL import Image
import numpy as np

from folium import Map, Circle, Marker
from streamlit_folium import st_folium
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

app = Flask(__name__)

# Load your trained models
image_model = load_model('image_classifier.h5')
disaster_model = load_model('disaster_classifier.h5')

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction_image = None
    prediction_disaster = None

    if request.method == 'POST':
        # Handle file upload and predictions here
        uploaded_file = request.files['file']
        if uploaded_file.filename != '':
            image_to_predict = Image.open(uploaded_file)
            image_to_predict = image_to_predict.resize((224, 224))
            img_array = np.expand_dims(image.img_to_array(image_to_predict), axis=0) / 255.0

            # Make image damage prediction
            prediction_image = "Damaged" if image_model.predict(img_array)[0][0] < 0.5 else "Undamaged"

            # Make disaster type prediction
            prediction_disaster = "Flood" if disaster_model.predict(img_array)[0][0] < 0.5 else "Tornado"

    return render_template('index.html', prediction_image=prediction_image, prediction_disaster=prediction_disaster)

if __name__ == '__main__':
    app.run(debug=True)
