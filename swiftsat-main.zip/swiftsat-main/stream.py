import streamlit as st
import pandas as pd
from folium import Map, Circle, Marker  # Import Folium for map creation
from streamlit_folium import st_folium

# Load data
data = pd.read_csv("sorted_data.csv")

# Ensure numerical data types
data["centroid_x"] = pd.to_numeric(data["centroid_x"], errors="coerce")
data["centroid_y"] = pd.to_numeric(data["centroid_y"], errors="coerce")

# Calculate map center
location = data.mean(numeric_only=True)[["centroid_y", "centroid_x"]].tolist()

# Create the map
m_2 = Map(location=location, tiles="openstreetmap", zoom_start=13)

# Add circles based on damage level
def generate_circles(row):
    COLOR_MAP = {
        "no-damage": "green",
        "minor-damage": "blue",
        "major-damage": "yellow",
        "destroyed": "red",
        "un-classified": "black",
    }
    circles = []
    for damage_type, color in COLOR_MAP.items():
        if row[damage_type] > 0:  # Check if damage value exists and is greater than 0
            circles.append(
                Circle(
                    location=row[["centroid_y", "centroid_x"]].tolist(),
                    radius=row[damage_type],  # Adjust radius based on damage level
                    color=color,
                    fill_opacity=0.5,  # Adjust opacity for better visualization
                )
            )
    return circles

for idx, row in data.iterrows():
    for circle in generate_circles(row):
        circle.add_to(m_2)

# Display the map in Streamlit
st.title("Visualizing Damage Distribution")  # Clear title for context
st_folium(m_2)  # Display the interactive map

