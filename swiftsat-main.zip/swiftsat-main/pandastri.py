import pandas as pd
import folium
from folium import Choropleth, Circle, Marker
from folium.plugins import HeatMap, MarkerCluster
import streamlit as st


data=pd.read_csv('sorted_data.csv')

df_generator = data.iterrows()

data['centroid_x'] = pd.to_numeric(data['centroid_x'], errors='coerce')  # Handle potential errors
data['centroid_y'] = pd.to_numeric(data['centroid_y'], errors='coerce')

# Calculate the mean after ensuring numerical types



from IPython.core.display import display, HTML
def generate_gmaps_link(lat, long):
    link = f"https://www.google.com/maps/@?api=1&map_action=map&center={lat},{long}&zoom=18&basemap=satellite"
    return HTML(f"""<a href="{link}" target="_blank">{link}</a>""")


index, row = next(df_generator)
print(f"Row {index}: {row}")


generate_gmaps_link(row.centroid_x, row.centroid_y)


def embed_map(m, file_name):
    from IPython.display import IFrame
    m.save(file_name)
    return IFrame(file_name, width='100%', height='500px')






def generate_circle(row):
    
    COLOR_MAP = {
        "no-damage": 'green',
        "minor-damage": 'blue',
        "major-damage": '#ffff00',
        "destroyed": 'red',
        "un-classified": 'black'
    }
    
    for damage_type, color in COLOR_MAP.items():
        yield Circle(
            location=row.loc[['centroid_y','centroid_x']].tolist(),
            radius=row.loc[damage_type],
            color=color)
        

location = data.mean(numeric_only=True)[['centroid_y', 'centroid_x']].tolist()




# mean latitude and longitude
# Create a map
m_2 = folium.Map(location=location, tiles='openstreetmap', zoom_start=13)

# Add points to the map
for idx, row in data.iterrows():
    generator = generate_circle(row)
    for circle in generator:
        circle.add_to(m_2)

# Display the map
st.write(embed_map(m_2, 'm_2.html'))